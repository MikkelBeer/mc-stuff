package org.randomizer.randomizer;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.attribute.Attribute;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.EntitySpawnEvent;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.inventory.CraftingInventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.*;

public final class Randomizer extends JavaPlugin implements Listener{
    private final Map<Material, Material> blockDrops = new HashMap<>();
    private final Map<EntityType, List<ItemStack>> mobDrops = new HashMap<>();
    private final Map<String, ItemStack> craftingRecipes = new HashMap<>();
    private final Random random = new Random();

    @Override
    public void onEnable() {
        Bukkit.getPluginManager().registerEvents(this, this);
        loadRandomizations();
        getLogger().info("Randomizer Plugin enabled!");
    }

    @Override
    public void onDisable() {
        saveRandomizations();
        getLogger().info("Randomizer Plugin disabled!");
    }

    private void loadRandomizations() {
        FileConfiguration config = getConfig();

        // Load or generate block drops
        if (config.contains("blockDrops")) {
            for (String key : config.getConfigurationSection("blockDrops").getKeys(false)) {
                blockDrops.put(Material.valueOf(key), Material.valueOf(config.getString("blockDrops." + key)));
            }
        } else {
            for (Material material : Material.values()) {
                if (material.isBlock()) {
                    blockDrops.put(material, Material.values()[random.nextInt(Material.values().length)]);
                }
            }
        }

        // Load or generate mob drops
        if (config.contains("mobDrops")) {
            for (String key : config.getConfigurationSection("mobDrops").getKeys(false)) {
                List<ItemStack> drops = new ArrayList<>();
                for (String item : config.getStringList("mobDrops." + key)) {
                    drops.add(new ItemStack(Material.valueOf(item)));
                }
                mobDrops.put(EntityType.valueOf(key), drops);
            }
        } else {
            for (EntityType type : EntityType.values()) {
                if (type.isAlive()) {
                    List<ItemStack> drops = new ArrayList<>();
                    for (int i = 0; i < 3; i++) { // Generate up to 3 random drops
                        drops.add(new ItemStack(Material.values()[random.nextInt(Material.values().length)]));
                    }
                    mobDrops.put(type, drops);
                }
            }
        }

        // Load or generate crafting recipes
        if (config.contains("craftingRecipes")) {
            for (String key : config.getConfigurationSection("craftingRecipes").getKeys(false)) {
                craftingRecipes.put(key, new ItemStack(Material.valueOf(config.getString("craftingRecipes." + key))));
            }
        } else {
            for (Material material : Material.values()) {
                if (material.isItem()) {
                    craftingRecipes.put(material.name(), new ItemStack(Material.values()[random.nextInt(Material.values().length)]));
                }
            }
        }
    }

    private void saveRandomizations() {
        FileConfiguration config = getConfig();
        config.set("blockDrops", null);
        config.set("mobDrops", null);
        config.set("craftingRecipes", null);

        // Save block drops
        for (Map.Entry<Material, Material> entry : blockDrops.entrySet()) {
            config.set("blockDrops." + entry.getKey().name(), entry.getValue().name());
        }

        // Save mob drops
        for (Map.Entry<EntityType, List<ItemStack>> entry : mobDrops.entrySet()) {
            List<String> drops = new ArrayList<>();
            for (ItemStack item : entry.getValue()) {
                drops.add(item.getType().name());
            }
            config.set("mobDrops." + entry.getKey().name(), drops);
        }

        // Save crafting recipes
        for (Map.Entry<String, ItemStack> entry : craftingRecipes.entrySet()) {
            config.set("craftingRecipes." + entry.getKey(), entry.getValue().getType().name());
        }

        saveConfig();
    }

    @EventHandler
    public void onBlockBreak(BlockBreakEvent event) {
        Material blockType = event.getBlock().getType();
        if (blockDrops.containsKey(blockType)) {
            event.setDropItems(false);
            event.getBlock().getWorld().dropItemNaturally(event.getBlock().getLocation(), new ItemStack(blockDrops.get(blockType)));
        }
    }

    @EventHandler
    public void onEntityDeath(EntityDeathEvent event) {
        EntityType entityType = event.getEntityType();
        if (mobDrops.containsKey(entityType)) {
            event.getDrops().clear();
            event.getDrops().addAll(mobDrops.get(entityType));
        }
    }

    @EventHandler
    public void onCrafting(PrepareItemCraftEvent event) {
        CraftingInventory inventory = event.getInventory();
        if (inventory.getResult() != null && craftingRecipes.containsKey(inventory.getResult().getType().name())) {
            inventory.setResult(craftingRecipes.get(inventory.getResult().getType().name()));
        }
    }

    @EventHandler
    public void onEntitySpawn(EntitySpawnEvent event) {
        if (event.getEntity() instanceof LivingEntity) {
            LivingEntity entity = (LivingEntity) event.getEntity();
            Random random = new Random();

            // Random health between 5 and 50
            double randomHealth = 5 + random.nextInt(46); // Upper bound is exclusive
            if (entity.getAttribute(Attribute.MAX_HEALTH) != null) {
                entity.getAttribute(Attribute.MAX_HEALTH).setBaseValue(randomHealth);
            }
            entity.setHealth(randomHealth); // Set current health to max health

            // Random damage between 2 and 20
            double randomDamage = 2 + random.nextInt(19);
            if (entity.getAttribute(Attribute.ATTACK_DAMAGE) != null) {
                entity.getAttribute(Attribute.ATTACK_DAMAGE).setBaseValue(randomDamage);
            }

            // Optionally make passive mobs aggressive
            if (entity instanceof Mob) {
                Player target = Bukkit.getOnlinePlayers().stream().findAny().orElse(null);
                if (target != null) {
                    ((Mob) entity).setTarget(target);
                }
            }
        }
    }
}
